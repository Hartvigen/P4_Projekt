﻿namespace HandWrittenScannerParser
{
    public enum Kinds
    {
        Number,
        IDENT,
        LBrack,
        RBrack,
        Assign,
        LParen,
        RParen,
        Func
    }
}
