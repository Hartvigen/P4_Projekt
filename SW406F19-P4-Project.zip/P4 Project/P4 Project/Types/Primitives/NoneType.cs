namespace P4_Project.Types.Primitives
{
    public class NoneType : BaseType
    {
        public override string ToString()
        {
            return "none";
        }
    }
}
