
# MAGIA
Mastering Algorithms and Graphs with Illustrative Assistance.

# The Project
A project made by the university group sw406f19 from AAU. The project focuses on creating a graph programming language.

# Build
The provided code, alongside the related NuGet Dependencies, can compile the MAGIA compiler in Visual Studio.
The MAGIA compiler can compile MAGIA Code to DOT code and using the Graphviz.NET NuGet Package create images directly.
The Compiler is a hybrid compiler and performs a lot of Interpretation.

# How to use
Note that the project only executes correctly on Windows machines, due to the nature of NuGet packages.

In order to run the interpreter MagiaC.exe, ensure that it is placed in the folder "...\P4 Project\P4 Project\bin\Debug".

Ensure that Graphviz is installed, by checking that the file "dot.exe", is placed relative to MagiaC.exe at "..\..\Graphviz\bin".

The interpreter can be run with the command:
"MagiaC.exe [interpreterOption] [Filepath]"

Interpreter options can be found by running MagiaC.exe without arguments.

Alternatively, open the project in visual studio, and run the program.

Test programs can be found at "...\P4 Project\TestPrograms"

# Contact
sw406f19@cs.aau.dk
This email will probably not be monitored after fall 2019.

# License
See License, all copyrighted material belongs to the respective copyright holders.
